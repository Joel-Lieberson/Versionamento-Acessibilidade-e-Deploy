
// mask.js — input masks (CPF, phone, CEP)
const onlyDigits = (v) => v.replace(/\D/g,'');

function maskCPF(v){
  v = onlyDigits(v).slice(0,11);
  const parts = [];
  if(v.length>0) parts.push(v.slice(0,3));
  if(v.length>3) parts.push(v.slice(3,6));
  if(v.length>6) parts.push(v.slice(6,9));
  let end = v.slice(9,11);
  return parts.join('.').replace(/\.$/,'') + (end?'-'+end:'');
}

function maskPhone(v){
  v = onlyDigits(v).slice(0,11);
  if(v.length <= 10){
    const ddd = v.slice(0,2);
    const p1 = v.slice(2,6);
    const p2 = v.slice(6,10);
    return (ddd?'('+ddd+') ':'') + p1 + (p2?'-'+p2:'');
  }else{
    const ddd = v.slice(0,2);
    const p1 = v.slice(2,7);
    const p2 = v.slice(7,11);
    return (ddd?'('+ddd+') ':'') + p1 + (p2?'-'+p2:'');
  }
}

function maskCEP(v){
  v = onlyDigits(v).slice(0,8);
  const p1 = v.slice(0,5);
  const p2 = v.slice(5,8);
  return p1 + (p2?'-'+p2:'');
}

document.addEventListener('DOMContentLoaded', () => {
  const cpf = document.querySelector('#cpf');
  const tel = document.querySelector('#telefone');
  const cep = document.querySelector('#cep');
  [ [cpf, maskCPF], [tel, maskPhone], [cep, maskCEP] ].forEach(([el,fn]) => {
    if(!el) return;
    el.addEventListener('input', e => { e.target.value = fn(e.target.value); });
    el.addEventListener('blur', e => { e.target.value = fn(e.target.value); });
  });
});
