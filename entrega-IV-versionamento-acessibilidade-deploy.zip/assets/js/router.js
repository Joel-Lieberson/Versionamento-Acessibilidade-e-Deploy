
// router.js — Hash-based SPA router
export class Router {
  constructor(routes){
    this.routes = routes;
    window.addEventListener('hashchange', () => this.resolve());
    document.addEventListener('DOMContentLoaded', () => this.resolve());
  }
  resolve(){
    const path = location.hash.replace(/^#\/?/, '') || 'inicio';
    const [route, ...rest] = path.split('/');
    const handler = this.routes[route] || this.routes['404'];
    if(handler){ handler({ params: rest }); }
    // update active link
    document.querySelectorAll('[data-route]').forEach(a => {
      const href = a.getAttribute('href') || '';
      const match = href.includes('#/' + route);
      a.classList.toggle('active', match);
    });
  }
}
