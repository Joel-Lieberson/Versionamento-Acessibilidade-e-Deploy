
// storage.js — LocalStorage helpers
const KEY = 'ifm_cadastros';

export const Store = {
  all(){
    try{
      return JSON.parse(localStorage.getItem(KEY) || '[]');
    }catch(e){ return []; }
  },
  add(entry){
    const list = Store.all();
    list.push({ ...entry, createdAt: new Date().toISOString() });
    localStorage.setItem(KEY, JSON.stringify(list));
  }
};
